package zame.game.feature.game;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.FrameLayout;

/** Floating, touch-draggable and user-resizable single-player mod-menu shell. */
public class FirestrikeModMenu extends LinearLayout {
    public static volatile boolean boxEspEnabled;
    public static volatile boolean tracersEnabled;
    public static volatile boolean aimAssistEnabled;
    public static volatile int aimFov = 90;
    public static volatile int aimSmoothness = 50;

    private final LinearLayout panel;
    private final TextView sizeLabel;
    private int panelWidth;
    private int panelHeight;
    private float downRawX, downRawY;
    private int downX, downY;

    public FirestrikeModMenu(Context context) {
        super(context);
        setOrientation(VERTICAL);
        setGravity(Gravity.TOP | Gravity.LEFT);
        setClipChildren(false);
        setClipToPadding(false);

        panelWidth = dp(270);
        panelHeight = dp(430);
        panel = new LinearLayout(context);
        panel.setOrientation(VERTICAL);
        panel.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(13, 17, 28));
        bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), Color.rgb(0, 150, 255));
        panel.setBackground(bg);
        addView(panel, new FrameLayout.LayoutParams(panelWidth, panelHeight));

        TextView header = text("FIRESTRIKE.EXE   ⋮⋮", 16, Color.WHITE, true);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), dp(8), dp(8), dp(8));
        header.setBackgroundColor(Color.rgb(0, 76, 130));
        panel.addView(header, matchWrap());
        header.setOnTouchListener(new OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams)getLayoutParams();
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    downRawX = event.getRawX(); downRawY = event.getRawY();
                    downX = lp.leftMargin; downY = lp.topMargin; return true;
                }
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    lp.leftMargin = downX + (int)(event.getRawX() - downRawX);
                    lp.topMargin = downY + (int)(event.getRawY() - downRawY);
                    setLayoutParams(lp); return true;
                }
                return event.getAction() == MotionEvent.ACTION_UP;
            }
        });

        addToggle("BOX ESP", new ToggleSetter() { public void set(boolean v) { boxEspEnabled = v; } });
        addToggle("TRACERS", new ToggleSetter() { public void set(boolean v) { tracersEnabled = v; } });
        addToggle("FOV AIM ASSIST", new ToggleSetter() { public void set(boolean v) { aimAssistEnabled = v; } });
        addSeek("AIM FOV", 10, 180, aimFov, new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { aimFov = p + 10; }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        addSeek("AIM SMOOTHNESS", 0, 100, aimSmoothness, new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) { aimSmoothness = p; }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        sizeLabel = text("MENU SIZE: 100%", 12, Color.LTGRAY, false);
        panel.addView(sizeLabel, matchWrap());
        SeekBar resize = new SeekBar(context);
        resize.setMax(70);
        resize.setProgress(30);
        panel.addView(resize, matchWrap());
        resize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                float scale = 0.7f + (p / 100.0f);
                sizeLabel.setText("MENU SIZE: " + Math.round(scale * 100) + "%");
                panelWidth = (int)(dp(270) * scale);
                panelHeight = (int)(dp(430) * scale);
                panel.setLayoutParams(new LayoutParams(panelWidth, panelHeight));
            }
            public void onStartTrackingTouch(SeekBar s) { }
            public void onStopTrackingTouch(SeekBar s) { }
        });
        Button hide = new Button(context);
        hide.setText("HIDE MENU");
        hide.setTextColor(Color.WHITE);
        hide.setBackgroundColor(Color.rgb(0, 100, 170));
        panel.addView(hide, matchWrap());
        final Button reopen = new Button(context);
        reopen.setText("OPEN FIRESTRIKE MENU");
        reopen.setTextSize(11);
        reopen.setTextColor(Color.WHITE);
        reopen.setBackgroundColor(Color.rgb(0, 76, 130));
        reopen.setVisibility(GONE);
        addView(reopen, new FrameLayout.LayoutParams(dp(170), dp(44)));
        hide.setOnClickListener(new OnClickListener() {
            public void onClick(View v) { panel.setVisibility(GONE); reopen.setVisibility(VISIBLE); }
        });
        reopen.setOnClickListener(new OnClickListener() {
            public void onClick(View v) { reopen.setVisibility(GONE); panel.setVisibility(VISIBLE); }
        });
    }

    private interface ToggleSetter { void set(boolean value); }
    private void addToggle(String label, final ToggleSetter setter) {
        final Button button = new Button(getContext());
        button.setText(label + "  OFF");
        button.setTextSize(12);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setBackgroundColor(Color.rgb(30, 42, 60));
        panel.addView(button, matchWrap());
        button.setOnClickListener(new OnClickListener() {
            private boolean enabled;
            public void onClick(View v) {
                enabled = !enabled; setter.set(enabled);
                button.setText(button.getText().toString().replace(enabled ? "OFF" : "ON", enabled ? "ON" : "OFF"));
                button.setBackgroundColor(enabled ? Color.rgb(0, 105, 170) : Color.rgb(30, 42, 60));
            }
        });
    }
    private void addSeek(String label, int min, int max, int value, SeekBar.OnSeekBarChangeListener listener) {
        panel.addView(text(label + ": " + value, 12, Color.WHITE, false), matchWrap());
        SeekBar seek = new SeekBar(getContext()); seek.setMax(max - min); seek.setProgress(value - min);
        panel.addView(seek, matchWrap()); seek.setOnSeekBarChangeListener(listener);
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(getContext()); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LayoutParams matchWrap() { return new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT); }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
