package zame.game.feature.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import zame.game.engine.Engine;
import zame.game.engine.entity.Monster;

/** HUD overlay for offline single-player monster ESP. */
public class FirestrikeEspOverlay extends View {
    private final Engine engine;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public FirestrikeEspOverlay(Context context, Engine engine) {
        super(context); this.engine = engine; setWillNotDraw(false); setClickable(false);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() * 0.5f, cy = getHeight() * 0.5f;
        if (FirestrikeModMenu.aimAssistEnabled) {
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2f);
            paint.setColor(0xAA00B7FF);
            canvas.drawCircle(cx, cy, (float)(getWidth() * (FirestrikeModMenu.aimFov / 360.0)), paint);
        }
        if (!FirestrikeModMenu.boxEspEnabled && !FirestrikeModMenu.tracersEnabled) return;
        float heroX = engine.state.heroX, heroY = engine.state.heroY, heroA = engine.state.heroA;
        float fov = 100.0f;
        for (Monster mon = engine.state.monsters.first(); mon != null; mon = mon.next) {
            if (mon.health <= 0 || !engine.levelRenderer.isMonsterVisible(mon)) continue;
            float dx = mon.x - heroX, dy = mon.y - heroY;
            float dist = (float)Math.sqrt(dx * dx + dy * dy);
            if (dist < 0.1f) continue;
            float bearing = (float)Math.toDegrees(Math.atan2(dy, dx));
            float delta = normalize(bearing - heroA);
            if (Math.abs(delta) > fov * 0.5f) continue;
            float sx = cx + (delta / fov) * getWidth();
            float boxH = Math.min(getHeight() * 0.8f, getHeight() / (dist * 0.42f));
            float boxW = boxH * 0.48f;
            float top = cy - boxH * 0.52f, bottom = cy + boxH * 0.48f;
            if (FirestrikeModMenu.tracersEnabled) {
                paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2f); paint.setColor(0xFFFF4D6D);
                canvas.drawLine(cx, getHeight(), sx, bottom, paint);
            }
            if (FirestrikeModMenu.boxEspEnabled) {
                paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2.5f); paint.setColor(0xFF00E5FF);
                canvas.drawRect(sx - boxW * 0.5f, top, sx + boxW * 0.5f, bottom, paint);
                paint.setStyle(Paint.Style.FILL); paint.setTextSize(12f);
                canvas.drawText("MONSTER " + (int)dist + "m", sx - boxW * 0.5f, top - 5f, paint);
            }
        }
    }

    private static float normalize(float angle) {
        while (angle > 180f) angle -= 360f;
        while (angle < -180f) angle += 360f;
        return angle;
    }
}
