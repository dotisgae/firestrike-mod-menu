package zame.game.feature.game;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import zame.game.core.util.Common;
import zame.game.engine.Engine;
import zame.game.engine.controller.HeroController;
import zame.game.feature.main.MainActivity;

public class GameView extends zame.game.core.widget.GLSurfaceView21
        implements zame.game.core.widget.GLSurfaceView21.Renderer {

    private Engine engine;
    private HeroController heroController;
    private FirestrikeEspOverlay espOverlay;

    public void setEspOverlay(FirestrikeEspOverlay overlay) { this.espOverlay = overlay; }

    public GameView(Context context) {
        super(context);
        initialize(context);
    }

    public GameView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize(context);
    }

    public void initialize(Context context) {
        this.engine = ((MainActivity)context).engine;
        this.heroController = engine.heroController;

        //noinspection MagicNumber
        setEGLConfigChooser(8, 8, 8, 8, 16, 8);

        setFocusable(true);
        requestFocus();
        setFocusableInTouchMode(true);
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        engine.onSurfaceCreated(gl);
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        engine.onSurfaceChanged(gl, width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        applyOfflineAimAssist();
        engine.onDrawFrame(gl);
        if (espOverlay != null) espOverlay.postInvalidate();
    }

    private void applyOfflineAimAssist() {
        if (!FirestrikeModMenu.aimAssistEnabled) return;
        float heroX = engine.state.heroX, heroY = engine.state.heroY;
        float current = engine.state.heroA;
        float bestDelta = Float.MAX_VALUE, bestAngle = current;
        for (zame.game.engine.entity.Monster mon = engine.state.monsters.first(); mon != null; mon = mon.next) {
            if (mon.health <= 0 || !engine.levelRenderer.isMonsterVisible(mon)) continue;
            float dx = mon.x - heroX, dy = mon.y - heroY;
            float target = (float)Math.toDegrees(Math.atan2(dy, dx));
            float delta = target - current;
            while (delta > 180f) delta -= 360f;
            while (delta < -180f) delta += 360f;
            if (Math.abs(delta) < bestDelta && Math.abs(delta) <= FirestrikeModMenu.aimFov * 0.5f) {
                bestDelta = Math.abs(delta); bestAngle = target;
            }
        }
        if (bestDelta == Float.MAX_VALUE) return;
        float delta = bestAngle - current;
        while (delta > 180f) delta -= 360f;
        while (delta < -180f) delta += 360f;
        float factor = (FirestrikeModMenu.aimSmoothness <= 0) ? 1.0f : (1.0f / (1.0f + FirestrikeModMenu.aimSmoothness * 0.12f));
        engine.state.setHeroA((current + delta * factor + 360.0f) % 360.0f);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        return Common.canUseKey(keyCode) && heroController.onKeyDown(keyCode) || super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        return Common.canUseKey(keyCode) && heroController.onKeyUp(keyCode) || super.onKeyUp(keyCode, event);

    }

    @SuppressLint({ "ObsoleteSdkInt", "ClickableViewAccessibility" })
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        heroController.onTouchEvent(event);

        try {
            //noinspection MagicNumber
            Thread.sleep((Build.VERSION.SDK_INT < 8) ? 16 : 1);
        } catch (InterruptedException e) {
            // ignored
        }

        return true;
    }

    @Override
    public boolean onTrackballEvent(MotionEvent event) {
        heroController.onTrackballEvent(event);
        return true;
    }
}
